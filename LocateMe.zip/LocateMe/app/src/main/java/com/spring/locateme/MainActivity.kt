package com.spring.locateme

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Geocoder
import android.location.Location
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.ResultReceiver
import android.util.Log
import com.google.android.material.snackbar.Snackbar
import androidx.appcompat.app.AppCompatActivity
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.PermissionChecker

import kotlinx.android.synthetic.main.activity_main.*
import java.security.Permission
import java.util.jar.Manifest

class MainActivity : AppCompatActivity(), View.OnClickListener{

    var locationManager: LocationManager? = null;
    var texLocation : TextView? = null;
    var buttonLocateMe : Button? = null;


    private var lastLocation: Location? = null
    private lateinit var resultReceiver: AddressResultReceiver

    var addressOutput: String? = null;

    // ...

    private fun startIntentService() {

        Log.v("Location", "starting FetchAddressIntentService...")

        val intent = Intent(this, FetchAddressIntentService::class.java).apply {
            putExtra(Constants.RECEIVER, resultReceiver)
            putExtra(Constants.LOCATION_DATA_EXTRA, lastLocation)
        }
        startService(intent)
    }

    override fun onClick(v: View?) {

        when (v?.id){

            R.id.button_locateMe -> {Log.v("location", "locateMe Clicked");
                updateLocation();}

        }
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    fun updateLocation (){

        requestLocationPermissions();

        if(checkCallingOrSelfPermission(android.Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED &&
            checkCallingOrSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED)
        Log.v("Location:", locationManager?.getLastKnownLocation(LocationManager.GPS_PROVIDER).toString());

        lastLocation = locationManager?.getLastKnownLocation(LocationManager.GPS_PROVIDER)

        if (!Geocoder.isPresent()) {
            Toast.makeText(this@MainActivity,
                "Geocoder Not Available!",
                Toast.LENGTH_LONG).show()
            return;
        }

        // Start service and update UI to reflect new location
        startIntentService()

        //texLocation?.setText(locationManager?.getLastKnownLocation(LocationManager.GPS_PROVIDER).toString());

    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        setSupportActionBar(toolbar)

        Log.v("Location: ","onCreateCalled..");

        locationManager = getSystemService(Context.LOCATION_SERVICE) as LocationManager


        buttonLocateMe = findViewById<Button>(R.id.button_locateMe);
        texLocation = findViewById<TextView>(R.id.textView_userLocation);

        var mHandler = Handler()

        resultReceiver = AddressResultReceiver(mHandler)

        buttonLocateMe?.setOnClickListener(object : View.OnClickListener {

                override fun onClick(v: View?) {

                    Log.v("Location:", "locateMe Clicked!!");

                    updateLocation();
                }

            });

            //texLocation.setOnClickListener(this);

        fab.setOnClickListener { view ->
            Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                .setAction("Action", null).show();


        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Inflate the menu; this adds items to the action bar if it is present.
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        return when (item.itemId) {
            R.id.action_settings -> true
            else -> super.onOptionsItemSelected(item)
        }
    }

    fun requestLocationPermissions(){

        if(Build.VERSION.SDK_INT > Build.VERSION_CODES.M){

            requestPermissions(arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION, android.Manifest.permission.ACCESS_COARSE_LOCATION), 0);
        }

    }

    // ...
    internal inner class AddressResultReceiver(handler: Handler) : ResultReceiver(handler) {

        override fun onReceiveResult(resultCode: Int, resultData: Bundle?) {

            // Display the address string
            // or an error message sent from the intent service.
            addressOutput = resultData?.getString(Constants.RESULT_DATA_KEY) ?: ""
            displayAddressOutput()

            // Show a toast message if an address was found.
            if (resultCode == Constants.SUCCESS_RESULT) {
                Toast.makeText(this@MainActivity, "Address found!!", Toast.LENGTH_SHORT).show();
            }

        }
    }


    fun displayAddressOutput(){

        texLocation?.setText(addressOutput)
    }
}
